# v2.5 Integrated Repair + QC

The repair workflow is now synchronized with QC measurements.

**Workflow:** Select region → Preview repair → Compare Before/After → Undo/Redo → Export → Automatic re-QC.

Supported operations:
- selection-aware gain
- high-pass
- DC removal
- limiter/ceiling preview
- trim/delete
- undo/redo
- rendered output re-analysis

The original source is never overwritten by the repair session.
