# Castwise Audio Doctor v2.5.0 — Delivery Profiles & Compliance Engine

v2.5 adds configurable engineering delivery checks for Radio, Podcast, Streaming,
Broadcast Safe, and custom profiles.

## Checks
- Integrated loudness target and tolerance
- Oversampled true-peak approximation ceiling
- Clipping samples
- Longest silence
- Minimum health score
- Optional sample-rate and channel constraints

Results are PASS / WARN / FAIL and can be exported as an engineering delivery report.

## Important
The delivery check is an engineering aid, not regulatory certification.
True peak remains an oversampled approximation and should be validated against
the receiving station/client's specified meter and standard when contractual
compliance is required.
