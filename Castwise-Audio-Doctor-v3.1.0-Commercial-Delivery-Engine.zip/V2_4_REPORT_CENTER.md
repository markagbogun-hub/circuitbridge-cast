# v2.5 Professional Batch QC Report Center

Generate a delivery-oriented report after batch repair/QC:
- PASS/WARN/FAIL/ERROR summary
- average score
- per-file before/after loudness and score
- delivery flags and failure reasons
- CSV, JSON, HTML and PDF outputs
- timestamped report metadata

Reports are engineering aids, not regulatory certification.
