# Castwise Store Deployment

## Architecture
Castwise website/store -> Stripe Checkout -> Stripe webhook -> Castwise License Server -> customer portal.

## Hosting
The store is FastAPI-based and can run on a normal Linux VPS/cloud host.
For WordPress, embed/link the store's product and checkout pages from the Castwise Studio website,
or implement the same flow as a WordPress plugin.

## Before public launch
- Replace SQLite with PostgreSQL.
- Add real customer authentication.
- Implement the webhook call to the license server.
- Add license download authorization.
- Put installer files behind authenticated/customer-specific download links.
- Configure Stripe products/prices.
- Enable HTTPS.
- Add privacy, EULA, refund and support pages.
- Code-sign the Windows installer.
