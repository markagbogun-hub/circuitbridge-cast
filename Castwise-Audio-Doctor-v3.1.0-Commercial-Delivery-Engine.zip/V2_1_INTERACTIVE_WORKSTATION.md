# v2.5 Interactive Broadcast QC Workstation

The v2.5 layer adds an interactive Qt/Matplotlib timeline:
- zoom and scroll
- click/drag region selection
- playhead navigation
- visible QC marker lines
- dedicated marker panel
- double-click marker navigation
- profile-driven analysis
- standalone workstation window

The waveform renderer is optimized for display by reducing dense source audio to a
bounded number of points. It does not alter the source file.
