# v2.5 Batch Repair & QC Automation

Queue large sets of audio files, select a broadcast profile, apply repeatable repair
operations, render new WAV outputs, automatically re-QC every output, and export
machine-readable batch results.

The source files are never overwritten. Output files use `_repaired.wav`.
