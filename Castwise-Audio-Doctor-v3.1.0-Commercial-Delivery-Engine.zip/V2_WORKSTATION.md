# Castwise Audio Doctor v2.5 — Broadcast QC Workstation

## QC workflow
Load → Analyze → Review timeline markers → Repair → Preview → Render → Re-QC → Export report.

### QC markers
- Silence / low-level regions
- Potential clipping regions
- Loudness and peak measurements
- Phase correlation for stereo sources

### Presets
Radio, Podcast, Streaming, and Broadcast Safe. Targets are configurable and should be
treated as engineering profiles rather than regulatory certification.

### Output
JSON QC result is available for automation and future customer-portal integrations.
True peak is explicitly reported as an oversampled approximation unless a separately
validated full implementation is used.
