# Castwise Audio Doctor 1.9 — Professional Repair Studio

## Workflow
1. Load/analyze source.
2. Mark a time selection.
3. Preview or apply gain/cleanup.
4. Detect silence and review markers.
5. Trim or delete selected regions when needed.
6. Apply DC removal/high-pass/limiter as required.
7. Undo/redo changes non-destructively inside the repair session.
8. Export a PCM-24 WAV and re-run QC on the rendered result.

## Safety
Repair operations are intentionally explicit. The source file is not overwritten by the repair engine. Always QC the rendered output after repair.
